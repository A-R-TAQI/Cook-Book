package com.example.cookbook;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class MethodFragment extends Fragment {
    private TextView mMethodTextView;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_method, container, false);
        mMethodTextView = view.findViewById(R.id.directionsTextView);
        // Retrieve the arguments
        Bundle args = getArguments();
        if (args != null) {
            String ingredients = args.getString("RecipeMethod");

            // Set the ingredients text in the TextView
            mMethodTextView.setText(ingredients);
        }

        return view;
    }
}