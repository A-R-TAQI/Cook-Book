package com.example.cookbook;



import java.util.List;

public class Recipes{
    private String title;
    private String ingredients;
    private String directions;

    private String recipeMethodTitle;
    private int photoResId; // Resource ID of the recipe photo

    public Recipes(String title, String ingredients,String recipeMethodTitle ,String directions, int photoResId) {
        this.title = title;
        this.ingredients = ingredients;
        this.recipeMethodTitle = recipeMethodTitle;
        this.directions = directions;
        this.photoResId = photoResId;

    }

    public String getTitle() {
        return title;
    }

    public String getIngredients() {
        return ingredients;
    }
    public String getRecipeMethodTitle() {return recipeMethodTitle;}
    public String getDirections() {
        return directions;
    }

    public int getPhotoResId() {
        return photoResId;
    }


}