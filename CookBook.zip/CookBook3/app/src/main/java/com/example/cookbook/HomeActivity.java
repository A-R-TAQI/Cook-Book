package com.example.cookbook;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.example.cookbook.databinding.ActivityHomeBinding;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {
    private ActivityHomeBinding binding;

    RecyclerView myrecyclerView;
    RecyclerViewAdapter myAdapter;

    List<Recipes> recipes1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.home); // Set the selected menu item

        binding.bottomNavigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

               if (item.getItemId() == R.id.search) {
                    startActivity(new Intent(HomeActivity.this, SearchActivity.class));
                   overridePendingTransition(R.transition.slide_in_right, R.transition.slide_out_left);
                    finish();
                    return true;
                } else if (item.getItemId() == R.id.profile) {
                    startActivity(new Intent(HomeActivity.this, UserActivity.class));
                   overridePendingTransition(R.transition.slide_in_right, R.transition.slide_out_left);
                    finish();
                    return true;
                } else if (item.getItemId() == R.id.planner) {
                    startActivity(new Intent(HomeActivity.this, PlannerActivity.class));
                   overridePendingTransition(R.transition.slide_in_right, R.transition.slide_out_left);
                    finish();
                    return true;
                }
                return false;
            }
        });
        recipes1 = new ArrayList<>();
        recipes1.add(new Recipes("Prawn Ghee Roast","250 grams Prawns , shelled and deveined\n" +
                "4 Dry Red Chillies\n" +
                "1/2 teaspoon Whole Black Peppercorns\n" +
                "1/2 teaspoon Cumin seeds (Jeera)\n" +
                "1/4 teaspoon Mustard seeds (Rai/ Kadugu)\n" +
                "1/4 Methi Seeds (Fenugreek Seeds)\n" +
                "1/2 teaspoon Coriander (Dhania) Seeds\n" +
                "1/2 Fennel seeds (Saunf)\n" +
                "1 tablespoon Tamarind , soaked in 1/4 cup warm water\n" +
                "1 teaspoon Turmeric powder (Haldi)\n" +
                "2 teaspoon Red Chilli powder\n" +
                "1/4 Cup Curd (Dahi / Yogurt)\n" +
                "1/2 Lemon juice\n" +
                "6 cloves Garlic\n" +
                "2 tablespoons Ghee , plus 1 teaspoon\n" +
                "Salt , as per taste.","Method",
                "1. To begin making the Prawn Ghee Roast recipe, soak the chillies in warm water for 1 hour, drain the water and reserve the chillies.\n" +
                        "\n" +
                        "2. Clean the prawns, wash and pat them dry.\n" +
                        "\n" +
                        "3. Soak tamarind in 1/4 cup warm water for 10 minutes. Once soaked squeeze the tamarind and extract the pulp.\n" +
                        "\n" +
                        "4. Heat a small fry pan, roast the pepper corns, fenugreek, mustard, fennel and cumin, once the spices stop to splutter, switch off the heat. Transfer the spices into a bowl, let it be cool, and grind to make a fine powder.\n" +
                        "\n" +
                        "5. Add the garlic and soaked chillies into a grinder with a splash of water and grind to form a smooth paste.\n" +
                        "\n" +
                        "6. Marinate the prawns with the lime juice, yoghurt, red chilli powder, turmeric and a pinch of salt for 20 minutes.\n" +
                        "\n" +
                        "7. Add 2 tablespoons ghee to a pan, place it on medium flame add the prawns in batches. Fry from both the sides until light brown. Remove the prawns from pan.\n" +
                        "\n" +
                        "8. Add garlic chilies paste into the remaining ghee, fry for 2 minutes, add prawns, roasted dry spice powder, remaining marination masala and salt, mix well and cook until oil gets separated.\n" +
                        "\n" +
                        "9. Add tamarind pulp, curry leaves and cook for 5 minutes on low flame, if required sprinkle some water.\n" +
                        "\n" +
                        "10. Add remaining 1 teaspoon ghee on top, mix and switch off the gas. Transfer the Prawn Ghee Roast into a serving bowl.\n" +
                        "\n" +
                        "11. Serve Prawn Ghee Roast as a side dish along with Mangalorean Style Kuvalyacho Pollav and Steamed Rice for a weekday meal.",
                R.drawable.prawns_ghee_roast_1));




        myrecyclerView = (RecyclerView)findViewById(R.id.recyclerView_id);

        myAdapter = new RecyclerViewAdapter(this,recipes1);

        myrecyclerView.setLayoutManager(new GridLayoutManager(this,1));

        myrecyclerView.setAdapter(myAdapter);



    }

}