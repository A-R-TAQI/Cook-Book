package com.example.cookbook;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class IngredientFragment extends Fragment {

    private TextView mIngredientsTextView;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ingredient, container, false);
        mIngredientsTextView = view.findViewById(R.id.ingredientsTextView);

        // Retrieve the arguments
        Bundle args = getArguments();
        if (args != null) {
            String ingredients = args.getString("RecipeIngredients");


            // Set the ingredients text in the TextView
            mIngredientsTextView.setText(ingredients);
        }

        return view;
    }
}
