package com.example.cookbook;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.cookbook.IngredientFragment;
import com.example.cookbook.MethodFragment;
import com.example.cookbook.R;
import com.example.cookbook.VPAdapter;
import com.google.android.material.tabs.TabLayout;

public class RecipeActivity extends AppCompatActivity {

    private TextView mRecipeName;
    private ImageView mRecipeImage;

    private TabLayout tabLayout;
    private ViewPager viewPager;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);

        tabLayout = findViewById(R.id.tabLayout);
        viewPager = findViewById(R.id.viewPager);

        tabLayout.setupWithViewPager(viewPager);

        Intent intent = getIntent();
        String Title = intent.getExtras().getString("RecipeName");
        String Ingredients = intent.getExtras().getString("RecipeIngredients");
        String MethodTitle = intent.getExtras().getString("RecipeMethodTitle");
        String Recipe = intent.getExtras().getString("Recipe");
        int RecipeImage = intent.getExtras().getInt("Thumbnail");

        mRecipeName = findViewById(R.id.titleTextView);
        mRecipeImage = findViewById(R.id.photoImageView);

        mRecipeName.setText(Title);
        mRecipeImage.setImageResource(RecipeImage);

        VPAdapter vpAdapter = new VPAdapter(getSupportFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);

        // Create ingredient and method fragments
        IngredientFragment ingredientFragment = new IngredientFragment();
        MethodFragment methodFragment = new MethodFragment();

        // Pass ingredients and method as arguments to the respective fragments
        Bundle ingredientArgs = new Bundle();
        ingredientArgs.putString("RecipeIngredients", Ingredients);
        ingredientFragment.setArguments(ingredientArgs);

        Bundle methodArgs = new Bundle();
        methodArgs.putString("Recipe", Recipe);
        methodFragment.setArguments(methodArgs);

        // Add the fragments to the adapter
        vpAdapter.addFragment(ingredientFragment, "Ingredients");
        vpAdapter.addFragment(methodFragment, "Method");

        viewPager.setAdapter(vpAdapter);
    }
}
