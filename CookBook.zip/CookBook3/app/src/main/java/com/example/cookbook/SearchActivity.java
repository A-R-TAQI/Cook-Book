package com.example.cookbook;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.example.cookbook.databinding.ActivityHomeBinding;
import com.example.cookbook.databinding.ActivitySearchBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class SearchActivity extends AppCompatActivity {
    private ActivitySearchBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        binding = ActivitySearchBinding.inflate(getLayoutInflater());
        super.onCreate(savedInstanceState);
        setContentView(binding.getRoot());

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.search); // Set the selected menu item

        binding.bottomNavigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                if (item.getItemId() == R.id.home) {
                    startActivity(new Intent(SearchActivity.this, HomeActivity.class));
                    overridePendingTransition(R.transition.slide_in_right, R.transition.slide_out_left);
                    finish();
                    return true;
                } else if (item.getItemId() == R.id.profile) {
                    startActivity(new Intent(SearchActivity.this, UserActivity.class));
                    overridePendingTransition(R.transition.slide_in_right, R.transition.slide_out_left);
                    finish();
                    return true;
                } else if (item.getItemId() == R.id.planner) {
                    startActivity(new Intent(SearchActivity.this, PlannerActivity.class));
                    overridePendingTransition(R.transition.slide_in_right, R.transition.slide_out_left);
                    finish();
                    return true;
                }
                return false;
            }
        });
    }
}